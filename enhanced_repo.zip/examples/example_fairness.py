"""
Demonstration of fairness‑aware early stopping on a synthetic dataset.

We train a logistic regression model on data generated from two
different groups.  The training loop monitors demographic parity
difference (difference between group error rates) and triggers early
stopping when fairness does not improve for several epochs.  The
example illustrates how early stopping can act as a regulariser that
balances accuracy and fairness【330857330321960†L29-L41】.
"""

import numpy as np

from fairness_early_stopping import (
    FairnessEarlyStopping,
    demographic_parity_difference,
)


def generate_dataset(n: int = 200) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Generate a binary classification dataset with a sensitive attribute."""
    rng = np.random.default_rng(1)
    X = rng.normal(size=(n, 2))
    sensitive = rng.integers(0, 2, size=n)
    # Generate labels with different biases per group
    weights = np.array([1.0, -1.0])
    logits = X @ weights + 0.5 * (sensitive - 0.5)
    probs = 1 / (1 + np.exp(-logits))
    y = (probs > 0.5).astype(float)
    return X, y, sensitive


def logistic_grad(w: np.ndarray, X: np.ndarray, y: np.ndarray) -> np.ndarray:
    logits = X @ w
    preds = 1 / (1 + np.exp(-logits))
    return X.T @ (preds - y) / len(y)


def loss_fn(preds: np.ndarray, y: np.ndarray) -> float:
    preds = np.clip(preds, 1e-12, 1 - 1e-12)
    return -np.mean(y * np.log(preds) + (1 - y) * np.log(1 - preds))


def main() -> None:
    X, y, sensitive = generate_dataset()
    n, d = X.shape
    w = np.zeros(d)
    callback = FairnessEarlyStopping(patience=5, min_delta=0.001, verbose=True)
    lr = 0.5
    max_epochs = 100
    for epoch in range(max_epochs):
        grad = logistic_grad(w, X, y)
        w -= lr * grad
        preds = 1 / (1 + np.exp(-X @ w))
        pred_labels = (preds > 0.5).astype(float)
        fair_stop = callback.step(epoch, y, pred_labels, sensitive)
        if fair_stop:
            break
    # Final evaluation
    preds = 1 / (1 + np.exp(-X @ w))
    y_pred = (preds > 0.5).astype(float)
    error_rate = np.mean(y_pred != y)
    fairness_metric = demographic_parity_difference(y, y_pred, sensitive)
    print(
        f"Training stopped at epoch {callback.stopped_epoch}, error rate={error_rate:.3f}, fairness metric={fairness_metric:.3f}"
    )


if __name__ == "__main__":
    main()