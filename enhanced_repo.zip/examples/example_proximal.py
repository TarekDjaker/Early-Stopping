"""
Demonstration of proximal gradient descent with early stopping.

This script solves a sparse linear regression problem using the
`ProximalEarlyStopping` class defined in ``proximal_early_stopping.py``.
It generates synthetic data with a sparse true parameter vector, runs
the solver and prints the stopping iteration as well as the recovery
error.  The example illustrates how early stopping acts as implicit
regularisation by preventing overfitting to noise.
"""

import numpy as np

from proximal_early_stopping import ProximalEarlyStopping


def main() -> None:
    # Generate synthetic data
    rng = np.random.default_rng(42)
    n, d = 200, 50
    # True sparse signal
    true_beta = np.zeros(d)
    nonzero_idx = rng.choice(d, size=5, replace=False)
    true_beta[nonzero_idx] = rng.normal(size=5)
    # Design matrix
    X = rng.normal(size=(n, d))
    noise = 0.1
    y = X @ true_beta + noise * rng.normal(size=n)

    # Fit with proximal gradient and early stopping
    solver = ProximalEarlyStopping(
        design=X,
        response=y,
        lam=0.05,
        step_size=0.5,
        tol=1e-5,
        patience=3,
        max_iter=1000,
    )
    beta_hat, stop_iter, _ = solver.fit()
    # Evaluate recovery
    mse = np.mean((beta_hat - true_beta) ** 2)
    print(f"Stopped at iteration {stop_iter} with MSE={mse:.4f}")


if __name__ == "__main__":
    main()