"""
Demonstration of component‑wise early stopping on a toy classification task.

We train a small multi‑layer perceptron on a synthetic dataset and
apply the `ComponentEarlyStopping` callback to freeze layers whose
gradient norms fall below a threshold.  This example shows how to
integrate the callback into a PyTorch training loop.  The model
quickly learns the simple task and freezes its hidden layers as soon
as their gradients vanish.
"""

import numpy as np
import torch
from torch import nn
from torch.utils.data import TensorDataset, DataLoader

from component_early_stopping import ComponentEarlyStopping


def generate_data(n: int = 200) -> Tuple[torch.Tensor, torch.Tensor]:
    """Generate a simple binary classification dataset."""
    rng = np.random.default_rng(0)
    X = rng.normal(size=(n, 2))
    # Non‑linear decision boundary
    y = (X[:, 0] ** 2 + X[:, 1] ** 2 < 1.0).astype(np.float32)
    return torch.tensor(X, dtype=torch.float32), torch.tensor(y, dtype=torch.float32)


class MLP(nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(2, 8),
            nn.ReLU(),
            nn.Linear(8, 8),
            nn.ReLU(),
            nn.Linear(8, 1),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x).squeeze(-1)


def main() -> None:
    X, y = generate_data()
    dataset = TensorDataset(X, y)
    loader = DataLoader(dataset, batch_size=32, shuffle=True)
    model = MLP()
    optimiser = torch.optim.Adam(model.parameters(), lr=0.01)
    loss_fn = nn.BCEWithLogitsLoss()
    callback = ComponentEarlyStopping(model, threshold=1e-4, verbose=True)

    num_epochs = 50
    for epoch in range(num_epochs):
        model.train()
        for batch_x, batch_y in loader:
            optimiser.zero_grad()
            logits = model(batch_x)
            loss = loss_fn(logits, batch_y)
            loss.backward()
            # Freeze parameters whose gradients are tiny
            frozen = callback.apply()
            optimiser.step()
        # Compute training accuracy
        with torch.no_grad():
            preds = (torch.sigmoid(model(X)) > 0.5).float()
            acc = (preds == y).float().mean().item()
        print(f"Epoch {epoch+1:02d}: loss={loss.item():.4f}, acc={acc:.4f}, frozen={len(frozen)}")
        # Early exit if all parameters have frozen
        if len(callback.summary()) == sum(p.numel() for p in model.parameters()):
            print("All parameters frozen. Stopping training.")
            break


if __name__ == "__main__":
    main()